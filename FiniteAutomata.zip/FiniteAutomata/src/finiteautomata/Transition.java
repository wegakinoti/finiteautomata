/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finiteautomata;

/**
 *
 * @author Wega Kinoti
 */
public class Transition {
   private String fromState;
   private char label;
   private String toState;
   
   public Transition(String fromState, char label, String toState){
      this.fromState = fromState;
      this.label = label;
      this.toState = toState;
   }

   /**
    * @return the fromState
    */
   public String getFromState() {
      return fromState;
   }

   /**
    * @param fromState the fromState to set
    */
   public void setFromState(String fromState) {
      this.fromState = fromState;
   }

   /**
    * @return the label
    */
   public char getLabel() {
      return label;
   }

   /**
    * @param label the label to set
    */
   public void setLabel(char label) {
      this.label = label;
   }

   /**
    * @return the toState
    */
   public String getToState() {
      return toState;
   }

   /**
    * @param toState the toState to set
    */
   public void setToState(String toState) {
      this.toState = toState;
   }
   
         
}
