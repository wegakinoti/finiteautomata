/*
 * In this assignment we are creating a DFA,
   First using a Prompt we find and read a file
   Output the alphabet used
 */
package finiteautomata;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.*;

/**
 *
 * @author Wega Kinoti
 */
public class FiniteAutomata {
   
   static String startState;
   static FiniteAutomata dfa = new FiniteAutomata();
   static ArrayList<String> acceptStates = new ArrayList<>();
   static ArrayList<String> dfaFile = new ArrayList<>();
   static ArrayList<Character> alphabet = new ArrayList<>();
   static ArrayList<Transition> transitions = new ArrayList<>();
   
   public static void fileChooser(){
      System.out.println("Please choose file containing DFA");
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
      int selection = fileChooser.showOpenDialog(null);
      if(selection == JFileChooser.APPROVE_OPTION){
         File selected = fileChooser.getSelectedFile();
         System.out.println("User picked file: " + selected.getAbsolutePath());
         try{
            Scanner scan = new Scanner(selected);
            while (scan.hasNextLine()){
               dfaFile.add(scan.nextLine());
            }
            scan.close();
         } 
         catch (FileNotFoundException e){
            System.out.println("Error");
         } 
      }
   }
   
   public static ArrayList<String> acceptStates(){
      startState = dfaFile.get(0);
      String [] accept = dfaFile.get(1).split(" ");
      acceptStates = new ArrayList<>(Arrays.asList(accept));
      System.out.println("Accept States: " + acceptStates);
      return acceptStates;
   }
   
   public static ArrayList<Transition> transitions(){
      for (int i = 2 ; i < dfaFile.size(); i++){
         String [] data = dfaFile.get(i).split(" ");
         char tempLabel = data[1].charAt(0);
         Transition transition = new Transition(data[0], tempLabel, data[2]);
         transitions.add(transition);
         dfa.setTransitions(transitions);
      }
      return transitions;
   }
   
   public void setTransitions(ArrayList<Transition> transitions) {
        dfa.transitions = transitions;
    }
   
   public static ArrayList<Character> alphabet(){
      for(int i = 2; i <dfaFile.size(); i++){
         String [] data = dfaFile.get(i).split(" ");
         char letter = data[1].charAt(0); 
         if(!alphabet.contains(letter)){
            alphabet.add(letter);
         }
      }
      System.out.println("Alphabet is: " + alphabet);
      return alphabet;
   }
   
   public static boolean acceptInput(String userInput){
      String current = startState;
      char label;
      for(int i = 0; i < userInput.length(); i++){
         label = userInput.charAt(i);
         for (Transition next : transitions) {    
            if (next.getFromState().matches(current) && label == next.getLabel()) {              
                   current = next.getToState();
                   break;
                }
         }
      }
      
      if (acceptStates.contains(current)){
         System.out.println("The input string is accepted");
         return true;
      }else{
         System.out.println("The input string is NOT accepted");
         return false;
      }
   }
   /**
    * @param args the command line arguments
    */
   public static void main(String[] args) {
      fileChooser(); //file location
      acceptStates(); //lists accept states
      transitions(); //finds transitions
      alphabet(); //lists alphabet of dfa
      
      String userInput = JOptionPane.showInputDialog("Please enter a string");
      acceptInput(userInput); //checks if User Input works
      
      String userContinue = JOptionPane.showInputDialog("Would you like to enter another string? Enter a Y to continue"); //loop to continue it
      do{
         userInput = JOptionPane.showInputDialog("Please enter a string");
         acceptInput(userInput);
         userContinue = JOptionPane.showInputDialog("Would you like to enter another string? Enter a Y to continue");
      } while (userContinue.equals("Y"));
      
   }
   
}
